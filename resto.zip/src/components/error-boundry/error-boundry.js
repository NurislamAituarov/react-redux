import React, {Component} from 'react';
import Error from '../error';

export default class ErrorBoundry extends Component {
    render() {
       
        return 1;
    }
}