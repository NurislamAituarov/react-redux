import RestoServiceContext from './resto-service-context';

export default RestoServiceContext;